// events/guildCreate.js
module.exports = {
    name: 'guildCreate',
    execute(guild) {
      //console.log(`Joined a new guild: ${guild.name}`);
    },
  };
  